package com.example.madproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.content.Intent;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {
    Button audioBtn;
    Button imageBtn;
    Button logoutBtn;
    FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        audioBtn = findViewById(R.id.audio);
        imageBtn = findViewById(R.id.image);
        logoutBtn = findViewById(R.id.logout);

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.getInstance().signOut();
                Intent backtoLogin = new Intent(HomeActivity.this,LoginActivity.class);
                startActivity(backtoLogin);
            }
        });

        audioBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendToAudio = new Intent(HomeActivity.this,AudioActivity.class);
                startActivity(sendToAudio);
            }
        });

        imageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendToImage = new Intent(HomeActivity.this,ImageActivity.class);
                startActivity(sendToImage);
            }
        });

    }
}
